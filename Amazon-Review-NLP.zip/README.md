# 🛒 Amazon Review Sentiment Analysis (NLP Workflow)

![Python](https://img.shields.io/badge/Python-3.8%2B-blue.svg)
![Machine Learning](https://img.shields.io/badge/Machine%20Learning-Sklearn-orange.svg)
![NLP](https://img.shields.io/badge/NLP-NLTK%20%7C%20TF--IDF-green.svg)

Dự án này là quy trình Machine Learning hoàn chỉnh (End-to-End Pipeline) nhằm phân loại cảm xúc từ các đánh giá trên Amazon, được xây dựng dựa trên cấu trúc Module hoá.

## 🚀 Hướng dẫn Cài đặt & Chạy dự án

**1. Clone kho lưu trữ này về máy:**
```bash
git clone https://github.com/your-username/Amazon-Review-NLP.git
cd Amazon-Review-NLP
```

**2. Cài đặt thư viện:**
```bash
pip install -r requirements.txt
```

**3. Chạy Pipeline (thông qua Scripts):**
- Bước 1: Chuẩn bị dữ liệu sơ bộ
```bash
python scripts/prepare_amazon_dataset.py
```
- Bước 2: Tự động gom code từ `nb_parts` để sinh ra Jupyter Notebook hoàn chỉnh
```bash
python scripts/generate_text_notebook.py
```
- Bước 3: Mở file `notebooks/02_Text_Amazon_Reviews.ipynb` bằng Jupyter Notebook và chạy toàn bộ (Run All).

## 🌐 Public Resources Page (GitHub Pages)
Truy cập trang giới thiệu dự án tại: [Link GitHub Pages của bạn]
(Mã nguồn trang web nằm trong thư mục `docs/`).
