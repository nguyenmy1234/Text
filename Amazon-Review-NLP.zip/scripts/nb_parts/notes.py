# MÔ TẢ DỰ ÁN
# Bài toán: Phân loại cảm xúc từ đánh giá Amazon.
# Dữ liệu: amazon_reviews_2.csv
# Phương pháp: TF-IDF, Logistic Regression & Naive Bayes.
