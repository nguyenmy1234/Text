# --- PHẦN 1: EDA ---
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

print("Loading data...")
df = pd.read_csv('../data/tabular/amazon_reviews_processed.csv')
print(f"Dataset shape: {df.shape}")
print(df.info())

plt.figure(figsize=(6,4))
sns.countplot(data=df, x='sentiment')
plt.title('Phân phối Cảm xúc (0: Tiêu cực, 1: Tích cực)')
plt.show()

df['review_length'] = df['reviewText'].astype(str).apply(len)
plt.figure(figsize=(8,5))
sns.histplot(df['review_length'], bins=50, kde=True)
plt.title('Phân phối độ dài văn bản đánh giá (ký tự)')
plt.xlim(0, 2000)
plt.show()
