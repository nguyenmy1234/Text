# --- PHẦN 4: SUMMARY (Tổng kết và Đánh giá) ---
from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

print("Classification Report - Logistic Regression:")
print(classification_report(y_test, y_pred_log))

cm = confusion_matrix(y_test, y_pred_log)
plt.figure(figsize=(6,5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Negative', 'Positive'], yticklabels=['Negative', 'Positive'])
plt.title('Confusion Matrix - Logistic Regression')
plt.xlabel('Dự đoán')
plt.ylabel('Thực tế')
plt.show()

print("KẾT LUẬN: Quy trình End-to-End đã chạy thành công.")
