# --- PHẦN 3: MODELING (Huấn luyện mô hình) ---
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score

log_reg = LogisticRegression(max_iter=1000, random_state=42)
nb_model = MultinomialNB()

print("Đang huấn luyện Logistic Regression...")
log_reg.fit(X_train_tfidf, y_train)

print("Đang huấn luyện Naive Bayes...")
nb_model.fit(X_train_tfidf, y_train)

y_pred_log = log_reg.predict(X_test_tfidf)
y_pred_nb = nb_model.predict(X_test_tfidf)

print(f"Độ chính xác (Logistic Regression): {accuracy_score(y_test, y_pred_log):.4f}")
print(f"Độ chính xác (Naive Bayes): {accuracy_score(y_test, y_pred_nb):.4f}")
