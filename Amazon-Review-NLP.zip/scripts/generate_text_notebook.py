import nbformat as nbf
import os

def create_notebook():
    nb = nbf.v4.new_notebook()
    parts_dir = 'scripts/nb_parts'
    parts = ['notes.py', 'part1_eda.py', 'part2_preparation.py', 'part3_modeling.py', 'part4_summary.py']
    
    nb['cells'].append(nbf.v4.new_markdown_cell("# Dự án Phân Tích Cảm Xúc Amazon Reviews\n*(Notebook được sinh tự động từ các scripts)*"))
    
    for part in parts:
        filepath = os.path.join(parts_dir, part)
        if os.path.exists(filepath):
            with open(filepath, 'r', encoding='utf-8') as f:
                nb['cells'].append(nbf.v4.new_code_cell(f.read()))
        else:
            print(f"Cảnh báo: Không tìm thấy {filepath}")

    os.makedirs('notebooks', exist_ok=True)
    output_notebook = 'notebooks/02_Text_Amazon_Reviews.ipynb'
    with open(output_notebook, 'w', encoding='utf-8') as f:
        nbf.write(nb, f)
    print(f"Đã sinh file Notebook thành công tại: {output_notebook}")

if __name__ == "__main__":
    create_notebook()
