import pandas as pd
import os

def prepare_data():
    input_path = 'data/tabular/amazon_reviews_2.csv'
    output_path = 'data/tabular/amazon_reviews_processed.csv'
    if not os.path.exists(input_path):
        print(f"Không tìm thấy {input_path}")
        return
    print("Đang đọc dữ liệu gốc...")
    df = pd.read_csv(input_path)
    df = df.dropna(subset=['reviewText'])
    df['sentiment'] = df['overall'].apply(lambda x: 1 if x >= 4 else 0)
    df_clean = df[['reviewText', 'sentiment', 'overall']]
    df_clean.to_csv(output_path, index=False)
    print(f"Đã xử lý xong và lưu tại: {output_path}")

if __name__ == "__main__":
    prepare_data()
