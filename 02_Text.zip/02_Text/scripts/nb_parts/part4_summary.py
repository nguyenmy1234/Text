# Phần 4: Tổng kết và mở rộng
md("""
## 4. TỔNG KẾT VÀ MỞ RỘNG

### 4.1. Đánh giá trên tập Test độc lập
Mô hình, siêu tham số và cấu hình đặc trưng đều đã được chốt ở Phần 3 (dựa trên Validation); tập Test chỉ được dùng **một lần** ở đây.
Bảng dưới so sánh tất cả mô hình trên cùng tập Test với 5 thước đo của đề (Accuracy, Precision, Recall, F1, ROC-AUC; trung bình macro).
""")

code(r"""
test_models = {'Dummy (lớp đa số)': models['Dummy (lớp đa số)'], 'LogisticRegression (baseline)': models['LogisticRegression'], **candidates}
test_results = pd.DataFrame({k: evaluate(m, X_test, y_test) for k, m in test_models.items()}).T
display(test_results.style.format(METRIC_FMT).highlight_max(color='#c6efce', axis=0))

test_pred = final_model.predict(X_test)
test_scores = get_scores(final_model, X_test)
print(f'=== {best_name} — TẬP TEST ({len(y_test)} mẫu) ===')
print(classification_report(y_test, test_pred, target_names=[CLASS_NAMES[k] for k in CLASSES], digits=3, zero_division=0))

fig, axes = plt.subplots(1, 3, figsize=(20, 5))
labels = [CLASS_NAMES[k] for k in CLASSES]
ConfusionMatrixDisplay(confusion_matrix(y_test, test_pred), display_labels=labels).plot(ax=axes[0], cmap='Blues', colorbar=False)
axes[0].set_title('Confusion matrix (số mẫu)')
ConfusionMatrixDisplay(confusion_matrix(y_test, test_pred, normalize='true'), display_labels=labels).plot(
    ax=axes[1], cmap='Blues', colorbar=False, values_format='.2f')
axes[1].set_title('Confusion matrix (chuẩn hóa theo hàng = Recall)')
Y_test = label_binarize(y_test, classes=CLASSES)
for k in CLASSES:
    fpr, tpr, _ = roc_curve(Y_test[:, k], test_scores[:, k])
    axes[2].plot(fpr, tpr, color=CLASS_COLORS[k], label=f'{CLASS_NAMES[k]} (AUC={roc_auc_score(Y_test[:, k], test_scores[:, k]):.3f})')
axes[2].plot([0, 1], [0, 1], 'k--', lw=1)
axes[2].set(title='ROC one-vs-rest (Test)', xlabel='False Positive Rate', ylabel='True Positive Rate'); axes[2].legend()
plt.tight_layout(); plt.show()
print('ROC-AUC theo lớp (Test):', {CLASS_NAMES[k]: round(float(roc_auc_score(Y_test[:, k], test_scores[:, k])), 3) for k in CLASSES})
""")

md(note("TEST"))

md("""
### 4.2. Câu hỏi: *Xử lý mất cân bằng và tuning giúp bắt thêm được bao nhiêu đánh giá tiêu cực / trung tính trên tập Test?*
So sánh 3 cấu hình trên **cùng tập Test**:
1. **Baseline** — Logistic Regression mặc định, không xử lý mất cân bằng.
2. **+ xử lý mất cân bằng** — Logistic Regression với `class_weight='balanced'`, cùng tham số mặc định.
3. **Mô hình cuối** — cấu hình đã tuning bằng GridSearchCV và chọn trên Validation.
""")

code(r"""
n_neg, n_neu = int((y_test == 0).sum()), int((y_test == 1).sum())
steps = [('1. Baseline LogReg', models['LogisticRegression']),
         ('2. + class_weight (LogReg)', models['LogisticRegression + balanced']),
         (f'3. Mô hình cuối: {best_name}', final_model)]
step_rows = []
for label, model in steps:
    pred = model.predict(X_test)
    cm = confusion_matrix(y_test, pred, labels=CLASSES)
    step_rows.append({'Cấu hình': label, **{k: v for k, v in evaluate(model, X_test, y_test).items() if k in ('Accuracy', 'F1', 'ROC-AUC')},
                      'Bắt Tiêu cực': int(cm[0, 0]), 'Bắt Trung tính': int(cm[1, 1]),
                      'Báo nhầm → Tiêu cực': int(cm[1:, 0].sum()), 'Báo nhầm → Trung tính': int(cm[[0, 2], 1].sum())})
steps_df = pd.DataFrame(step_rows).set_index('Cấu hình')
display(steps_df.style.format({'Accuracy': '{:.3f}', 'F1': '{:.3f}', 'ROC-AUC': '{:.3f}'}))
print(f'Tập Test có {n_neg} đánh giá Tiêu cực và {n_neu} đánh giá Trung tính.')

fig, axes = plt.subplots(1, 2, figsize=(15, 4.5))
rec = pd.DataFrame({'Tiêu cực': steps_df['Bắt Tiêu cực'] / n_neg, 'Trung tính': steps_df['Bắt Trung tính'] / n_neu})
rec.index = [f'Bước {i + 1}' for i in range(len(rec))]
rec.plot.bar(ax=axes[0], rot=0, color=[CLASS_COLORS[0], CLASS_COLORS[1]], ylim=(0, 1.05))
for c in axes[0].containers:
    axes[0].bar_label(c, fmt='%.2f')
axes[0].set(title='Recall của lớp Tiêu cực và Trung tính qua từng bước')
axes[1].bar(rec.index, steps_df['F1'].values, color='#4C72B0')
for x, v in enumerate(steps_df['F1'].values):
    axes[1].text(x, v + .01, f'{v:.3f}', ha='center')
axes[1].set(title='F1 macro qua từng bước', ylim=(0, 1))
plt.tight_layout(); plt.show()
""")

md(note("CREATIVE"))

md("""
### 4.3. Đặc trưng quan trọng: những từ nào kéo mô hình về từng lớp?
Với mô hình tuyến tính, hệ số của từng từ TF-IDF cho biết từ đó đẩy dự đoán về lớp nào (với MultinomialNB dùng chênh lệch log-xác suất so với trung bình các lớp).
""")

code(r"""
def class_word_weights(model):
    tfidf = model.named_steps['prep'].named_transformers_['text'].named_steps['tfidf']
    names = np.array(tfidf.get_feature_names_out())
    clf = model.named_steps['clf']
    if hasattr(clf, 'coef_'):
        W = clf.coef_[:, :len(names)]
    else:
        W = clf.feature_log_prob_ - clf.feature_log_prob_.mean(axis=0)
    return names, W


names, W = class_word_weights(final_model)
fig, axes = plt.subplots(1, 3, figsize=(20, 5.5))
top_by_class = {}
for k, ax in zip(CLASSES, axes):
    idx = np.argsort(W[k])[::-1][:15]
    top_by_class[k] = list(names[idx])
    ax.barh(names[idx][::-1], W[k][idx][::-1], color=CLASS_COLORS[k])
    ax.set(title=f'Top 15 từ/cụm từ đẩy về: {CLASS_NAMES[k]}', xlabel='Hệ số')
plt.tight_layout(); plt.show()
for k in CLASSES:
    print(f'{CLASS_NAMES[k]:11s}:', ', '.join(top_by_class[k]))
""")

md(note("IMPORTANCE"))

md("""
### 4.4. Phân tích lỗi (Error Analysis)
Mô hình hay đoán nhầm lớp nào sang lớp nào, và vì sao? Nhóm dùng lại điểm sao gốc (1–5) để xem lỗi tập trung ở mức sao nào.
""")

code(r"""
err = pd.DataFrame({'text': X_test['reviewText'], 'stars': stars.loc[X_test.index], 'actual': y_test, 'pred': test_pred,
                    'conf': test_scores.max(axis=1), 'word_count': X_test['reviewText'].str.split().str.len()})
err['correct'] = (err['actual'] == err['pred'])

print('Phân bố dự đoán theo điểm sao gốc (số mẫu):')
display(pd.crosstab(err['stars'], err['pred'].map(CLASS_NAMES)))

fig, axes = plt.subplots(1, 2, figsize=(15, 4.5))
acc_star = err.groupby('stars')['correct'].agg(['mean', 'size'])
axes[0].bar(acc_star.index.astype(int), acc_star['mean'], color=['#DD5145', '#DD5145', '#E0B341', '#55A868', '#55A868'])
for x, (m, n) in zip(acc_star.index.astype(int), acc_star.values):
    axes[0].text(x, m + .01, f'{m:.2f}\n(n={int(n)})', ha='center', fontsize=9)
axes[0].set(title='Tỉ lệ dự đoán đúng nhãn 3 lớp theo điểm sao gốc (Test)', xlabel='Số sao', ylim=(0, 1.15))

err['len_bin'] = pd.qcut(err['word_count'], 4, duplicates='drop')
acc_len = err.groupby('len_bin', observed=True)['correct'].mean()
axes[1].bar([str(i) for i in acc_len.index], acc_len.values, color='#8172B3')
for x, v in enumerate(acc_len.values):
    axes[1].text(x, v + .01, f'{v:.2f}', ha='center')
axes[1].set(title='Tỉ lệ dự đoán đúng theo độ dài đánh giá (số từ, chia 4 nhóm)', ylim=(0, 1.1))
plt.tight_layout(); plt.show()
display(acc_star.rename(columns={'mean': 'Tỉ lệ đúng', 'size': 'Số mẫu'}))
display(err.groupby('len_bin', observed=True)['correct'].agg(['mean', 'size']).rename(columns={'mean': 'Tỉ lệ đúng', 'size': 'Số mẫu'}))

cm = confusion_matrix(err['actual'], err['pred'], labels=CLASSES)
mistakes = [(i, j, cm[i, j]) for i in CLASSES for j in CLASSES if i != j]
print('Các kiểu nhầm lẫn (thực tế → dự đoán):')
for i, j, n in sorted(mistakes, key=lambda t: -t[2]):
    print(f'  {CLASS_NAMES[i]:10s} → {CLASS_NAMES[j]:10s}: {n}')


def show_errors(actual, pred, n=4):
    sub = err[(err['actual'] == actual) & (err['pred'] == pred)].sort_values('conf', ascending=False).head(n)
    print(f'\n--- Thực tế {CLASS_NAMES[actual]} → dự đoán {CLASS_NAMES[pred]} (các ca mô hình "tự tin" nhất) ---')
    for _, r in sub.iterrows():
        print(f'[{int(r.stars)} sao] {r.text[:260]}')


show_errors(0, 2); show_errors(1, 2); show_errors(2, 0)
""")

md(note("ERROR"))

md("""
### 4.5. Mở rộng 1 — Kiểm tra trên tập ngoài (`external_test.jsonl`, 5,000 đánh giá)
Tập này **không dùng để huấn luyện hay chọn mô hình**, chỉ để đo khả năng tổng quát hóa khi dữ liệu thay đổi (nhiều ngành hàng hơn, phân bố nhãn khác).
Giả định: nhãn `0–4` tương ứng 1–5 sao, được gộp về 3 lớp giống phần huấn luyện (0–1 → Tiêu cực, 2 → Trung tính, 3–4 → Tích cực).
Phần đầu của ô dưới kiểm tra giả định này.
""")

code(r"""
ext_raw, ext_path = read_jsonl_safe(EXTERNAL_FILE)
EXT_MAP = {0: 0, 1: 0, 2: 1, 3: 2, 4: 2}
ext = ext_raw.dropna(subset=['text']).copy()
ext['y'] = ext['label'].map(EXT_MAP)
X_ext = pd.DataFrame({'reviewText': ext['text'].values}).reindex(columns=BASE_COLS)
y_ext = ext['y'].values
print(f'Nguồn: {ext_path} | {len(ext):,} đánh giá | phân bố nhãn gốc: {ext["label"].value_counts().sort_index().to_dict()}')
print('Phân bố 3 lớp (tập ngoài):', {CLASS_NAMES[k]: f'{(y_ext == k).mean():.1%}' for k in CLASSES},
      '| (tập Test chính:', {CLASS_NAMES[k]: f'{(y_test == k).mean():.1%}' for k in CLASSES}, ')')

ext_pred = final_model.predict(X_ext)
share_pos = pd.Series(ext_pred == 2).groupby(ext['label'].values).mean()
print('Kiểm tra giả định — % bị dự đoán "Tích cực" theo nhãn gốc 0→4:', [f'{v:.0%}' for v in share_pos.values],
      '→ tăng đơn điệu:', bool(share_pos.is_monotonic_increasing))

ext_results = pd.DataFrame({k: evaluate(m, X_ext, y_ext) for k, m in
                            {'LogisticRegression (baseline)': models['LogisticRegression'], **candidates}.items()}).T
display(ext_results.style.format(METRIC_FMT).highlight_max(color='#c6efce', axis=0))

fig, axes = plt.subplots(1, 2, figsize=(15, 4.8))
ConfusionMatrixDisplay(confusion_matrix(y_ext, ext_pred, normalize='true'), display_labels=labels).plot(
    ax=axes[0], cmap='Blues', colorbar=False, values_format='.2f')
axes[0].set_title(f'{best_name}: confusion matrix chuẩn hóa (tập ngoài)')
ct = pd.crosstab(ext['label'], pd.Series(ext_pred, index=ext.index).map(CLASS_NAMES), normalize='index')[labels]
sns.heatmap(ct, annot=True, fmt='.2f', cmap='Blues', cbar=False, ax=axes[1])
axes[1].set(title='Tỉ lệ dự đoán theo nhãn gốc 0–4 (tương ứng 1–5 sao)', xlabel='Dự đoán', ylabel='Nhãn gốc')
plt.tight_layout(); plt.show()
""")

md(note("EXTERNAL"))

md("""
### 4.6. Mở rộng 2 — So sánh với mô hình Transformer pretrained (zero-shot)
Để so sánh ML truyền thống với Deep Learning, nhóm dùng mô hình `cardiffnlp/twitter-roberta-base-sentiment-latest` (RoBERTa đã huấn luyện sẵn cho cảm xúc,
đúng 3 lớp negative / neutral / positive) và dự đoán **zero-shot** (không huấn luyện lại) trên tập Test.
Ô này cần internet để tải mô hình (~500 MB) và chạy mất vài phút trên CPU; nếu lỗi hoặc đặt `RUN_TRANSFORMER = False` thì tự bỏ qua, không ảnh hưởng phần còn lại.
""")

code(r"""
RUN_TRANSFORMER = True
TRANSFORMER_NAME = 'cardiffnlp/twitter-roberta-base-sentiment-latest'
transformer_result = None

if RUN_TRANSFORMER:
    try:
        import torch
        from transformers import pipeline as hf_pipeline
        device = 0 if torch.cuda.is_available() else -1
        hf = hf_pipeline('sentiment-analysis', model=TRANSFORMER_NAME, device=device, truncation=True, max_length=128, top_k=None)
        outputs = hf(X_test['reviewText'].tolist(), batch_size=32)
        name_to_id = {'negative': 0, 'neutral': 1, 'positive': 2}
        hf_scores = np.zeros((len(outputs), 3))
        for i, out in enumerate(outputs):
            for item in out:
                hf_scores[i, name_to_id[item['label'].lower()]] = item['score']
        hf_pred = hf_scores.argmax(axis=1)
        transformer_result = {'Accuracy': accuracy_score(y_test, hf_pred),
                              'Precision': precision_score(y_test, hf_pred, average='macro', zero_division=0),
                              'Recall': recall_score(y_test, hf_pred, average='macro', zero_division=0),
                              'F1': f1_score(y_test, hf_pred, average='macro', zero_division=0),
                              'ROC-AUC': macro_auc(y_test, hf_scores),
                              'F1 Trung tính': f1_score(y_test, hf_pred, labels=[1], average='macro', zero_division=0)}
        compare = pd.DataFrame({f'{best_name} (ML truyền thống)': evaluate(final_model, X_test, y_test),
                                'RoBERTa pretrained (zero-shot)': transformer_result}).T
        display(compare.style.format(METRIC_FMT).highlight_max(color='#c6efce', axis=0))
        d_f1 = transformer_result['F1'] - evaluate(final_model, X_test, y_test)['F1']
        print(f"F1 macro: RoBERTa zero-shot = {transformer_result['F1']:.3f} | {best_name} = {evaluate(final_model, X_test, y_test)['F1']:.3f} "
              f"| chênh lệch = {d_f1:+.3f} ({'Transformer cao hơn' if d_f1 > 0 else 'ML truyền thống cao hơn'})")
        print(classification_report(y_test, hf_pred, target_names=labels, digits=3, zero_division=0))
        ConfusionMatrixDisplay(confusion_matrix(y_test, hf_pred, normalize='true'), display_labels=labels).plot(cmap='Blues', colorbar=False, values_format='.2f')
        plt.title('RoBERTa zero-shot: confusion matrix chuẩn hóa (Test)'); plt.show()
    except Exception as err_hf:
        print(f'Bỏ qua phần Transformer ({type(err_hf).__name__}: {err_hf}).')
else:
    print('RUN_TRANSFORMER = False -> bỏ qua.')
""")

md(note("TRANSFORMER"))

md("""
### 4.7. Demo hàm suy luận `predict_sample`
Hàm nhận **một câu đánh giá thô** (tiếng Anh), tự chạy toàn bộ pipeline (làm sạch → TF-IDF → mô hình) và trả về nhãn cùng xác suất.
Nếu mô hình cuối là LinearSVC (không có xác suất), độ tin cậy được tính bằng softmax của `decision_function` — chỉ mang tính tham khảo, chưa hiệu chỉnh.
""")

code(r"""
def predict_sample(text, model=final_model):
    x = pd.DataFrame([{'reviewText': text}]).reindex(columns=BASE_COLS)
    scores = get_scores(model, x)[0]
    if not hasattr(model, 'predict_proba'):
        e = np.exp(scores - scores.max())
        scores = e / e.sum()
    k = int(np.argmax(scores))
    return {'Nhãn dự đoán': CLASS_NAMES[k], 'Độ tin cậy': f'{scores[k]:.1%}',
            **{f'P({CLASS_NAMES[i]})': f'{scores[i]:.1%}' for i in CLASSES}}


demo_reviews = {
    'Khen rõ ràng': 'Works perfectly in my phone, fast and easy to install. Highly recommend this card!',
    'Chê rõ ràng': 'Card stopped working after two days and I lost all my photos. Waste of money, I want a refund.',
    'Phủ định (not good)': 'This card is not good. It does not work in my tablet and it is very slow.',
    'Trung tính / lưng chừng': 'It is okay for the price. Does the job, but nothing special.',
    'Có cả ưu và nhược': 'Great speed but the card failed after a month. Not sure I would buy it again.',
    'Rất ngắn': 'Fine.',
    'Ngoài miền (tai nghe)': 'The sound quality is not good at all and the battery died quickly.',
}
display(pd.DataFrame({k: predict_sample(v) for k, v in demo_reviews.items()}).T)
""")

md("### 4.8. Kết luận, hạn chế và hướng phát triển\n\n" + note("CONCLUSION"))
